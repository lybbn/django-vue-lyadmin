from django.apps import AppConfig


class LymonitorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.lymonitor'
