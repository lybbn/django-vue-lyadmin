# from django.contrib import admin
# from mysystem.models import *
# # Register your models here.
# admin.site.register(Post)
# admin.site.register(Role)
# admin.site.register(Dept)
# admin.site.register(Button)
# admin.site.register(Menu)
# admin.site.register(LoginLog)
#
